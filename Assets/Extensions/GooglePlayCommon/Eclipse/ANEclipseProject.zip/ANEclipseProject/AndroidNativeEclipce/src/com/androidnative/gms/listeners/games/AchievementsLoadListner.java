package com.androidnative.gms.listeners.games;

import java.util.Iterator;

import com.androidnative.AndroidNativeBridge;
import com.androidnative.gms.core.GameClientManager;
import com.google.android.gms.common.api.ResultCallback;
import com.google.android.gms.games.achievement.Achievement;
import com.google.android.gms.games.achievement.Achievements;
import com.google.android.gms.games.achievement.Achievements.LoadAchievementsResult;
import com.unity3d.player.UnityPlayer;

public class AchievementsLoadListner implements ResultCallback<Achievements.LoadAchievementsResult> {

	@Override
	public void onResult(LoadAchievementsResult arg0) {
		StringBuilder info = new StringBuilder();
		info.append(arg0.getStatus().getStatusCode());
		info.append(AndroidNativeBridge.UNITY_SPLITTER);
		
		

		Iterator<Achievement> iterator =  arg0.getAchievements().iterator();

		while (iterator.hasNext()) {

			Achievement ach = iterator.next();
			info.append(ach.getAchievementId());
			info.append(AndroidNativeBridge.UNITY_SPLITTER);
			info.append(ach.getName());
			info.append(AndroidNativeBridge.UNITY_SPLITTER);
			info.append(ach.getDescription());
			info.append(AndroidNativeBridge.UNITY_SPLITTER);

			if (ach.getType() == Achievement.TYPE_INCREMENTAL) {
				info.append(Integer.toString(ach
						.getCurrentSteps()));
				info.append(AndroidNativeBridge.UNITY_SPLITTER);
				info.append(Integer.toString(ach
						.getTotalSteps()));
				info.append(AndroidNativeBridge.UNITY_SPLITTER);
			} else {
				info.append("-1");
				info.append(AndroidNativeBridge.UNITY_SPLITTER);
				info.append("-1");
				info.append(AndroidNativeBridge.UNITY_SPLITTER);
			}

			info.append(Integer.toString(ach.getState()));
			info.append(AndroidNativeBridge.UNITY_SPLITTER);
			info.append(Integer.toString(ach.getType()));
			info.append(AndroidNativeBridge.UNITY_SPLITTER);

		}

		info.append(AndroidNativeBridge.UNITY_EOF);
		UnityPlayer.UnitySendMessage(GameClientManager.PlAY_SERVICE_LISTNER_NAME,
				"OnAchievementsLoaded", info.toString());
		
	}

}
