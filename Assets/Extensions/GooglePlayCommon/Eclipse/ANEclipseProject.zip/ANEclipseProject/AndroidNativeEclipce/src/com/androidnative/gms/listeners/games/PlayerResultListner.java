package com.androidnative.gms.listeners.games;


import java.util.Iterator;

import com.androidnative.AndroidNativeBridge;
import com.androidnative.gms.core.GameClientManager;
import com.google.android.gms.common.api.ResultCallback;
import com.google.android.gms.games.GamesStatusCodes;
import com.google.android.gms.games.Player;
import com.google.android.gms.games.Players;
import com.google.android.gms.games.Players.LoadPlayersResult;
import com.unity3d.player.UnityPlayer;

public class PlayerResultListner implements ResultCallback<Players.LoadPlayersResult> {

	@Override
	public void onResult(LoadPlayersResult arg0) {
int statusCode = arg0.getStatus().getStatusCode();
		
		
		StringBuilder result = new StringBuilder();
		result.append(statusCode);
		
		if (statusCode == GamesStatusCodes.STATUS_OK) {
			result.append(AndroidNativeBridge.UNITY_SPLITTER);
			
			Iterator<Player> iterator = arg0.getPlayers().iterator();
			while (iterator.hasNext()) {
				
				
				Player player = iterator.next();
				GameClientManager.addLoadedPlayerId(player.getPlayerId());
				
				result.append(player.getPlayerId());
				result.append(AndroidNativeBridge.UNITY_SPLITTER);
				result.append(player.getDisplayName());
				result.append(AndroidNativeBridge.UNITY_SPLITTER);
				result.append(player.getIconImageUrl());
				result.append(AndroidNativeBridge.UNITY_SPLITTER);
				result.append(player.getHiResImageUrl());
				result.append(AndroidNativeBridge.UNITY_SPLITTER);
				
				
				if(player.hasIconImage()) {
					result.append(1);
				} else {
					result.append(0);
				}
				
				result.append(AndroidNativeBridge.UNITY_SPLITTER);
				
				if(player.hasHiResImage()) {
					result.append(1);
				} else {
					result.append(0);
				}
				
				result.append(AndroidNativeBridge.UNITY_SPLITTER);
				
				
			}
			
			arg0.getPlayers().close();
			result.append(AndroidNativeBridge.UNITY_EOF);
			
		}
		
		UnityPlayer.UnitySendMessage(GameClientManager.PlAY_SERVICE_LISTNER_NAME, "OnPlayersLoaded", result.toString());
		
	}

	

}
