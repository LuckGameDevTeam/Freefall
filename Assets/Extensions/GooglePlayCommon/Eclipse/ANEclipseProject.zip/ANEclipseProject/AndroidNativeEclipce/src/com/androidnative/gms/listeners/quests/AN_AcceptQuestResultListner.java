package com.androidnative.gms.listeners.quests;

import android.util.Log;

import com.androidnative.AndroidNativeBridge;
import com.androidnative.gms.core.GameClientManager;
import com.google.android.gms.common.api.ResultCallback;
import com.google.android.gms.games.GamesStatusCodes;
import com.google.android.gms.games.quest.Quests;
import com.google.android.gms.games.quest.Quests.AcceptQuestResult;
import com.unity3d.player.UnityPlayer;

public class AN_AcceptQuestResultListner implements ResultCallback<Quests.AcceptQuestResult> {

	@Override
	public void onResult(AcceptQuestResult r) {
		
		Log.d(AndroidNativeBridge.TAG, "AN_AcceptQuestResultListner+");
	
		int statusCode = r.getStatus().getStatusCode();
		StringBuilder result = new StringBuilder();
		result.append(statusCode);
		result.append(AndroidNativeBridge.UNITY_SPLITTER);
		
		if (statusCode == GamesStatusCodes.STATUS_OK) {
			GameClientManager.GetInstance().updateQuest(r.getQuest());
		}
		
		
		if(r.getQuest() != null) {
			result.append(r.getQuest().getQuestId());
		} else  {
			result.append("0");
		}
		
		UnityPlayer.UnitySendMessage(GameClientManager.GOOGLE_PlAY_QUESTS_LISTNER_NAME, "OnGPQuestAccepted", result.toString());
		
	}

	
}
