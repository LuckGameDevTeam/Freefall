/** Automatically generated file. DO NOT MODIFY */
package com.example.androidnative;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}