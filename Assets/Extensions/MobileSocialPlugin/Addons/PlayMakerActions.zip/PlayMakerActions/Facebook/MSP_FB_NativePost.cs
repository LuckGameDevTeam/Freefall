using UnityEngine;
using System.Collections;


namespace HutongGames.PlayMaker.Actions {
	
	[ActionCategory("Mobile Social Plugin - Facebook")]
	public class MSP_FB_NativePost : FsmStateAction {
		
		public FsmString message;

		public override void OnEnter() {

			SPShareUtility.FacebookShare(message.Value);
			Finish();			
		}		
	}
}



