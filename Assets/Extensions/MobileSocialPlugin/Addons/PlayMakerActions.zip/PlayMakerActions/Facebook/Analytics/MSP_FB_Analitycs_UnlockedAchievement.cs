﻿using UnityEngine;
using System.Collections;

namespace HutongGames.PlayMaker.Actions {
	
	[ActionCategory("Mobile Social Plugin - Facebook")]
	public class MSP_FB_Analitycs_UnlockedAchievement : FsmStateAction {

		public FsmString description;
		
		public override void OnEnter() {
			SPFacebookAnalytics.UnlockedAchievement(description.Value);
			Finish ();
		}		
	}
}
