using UnityEngine;
using System.Collections;


namespace HutongGames.PlayMaker.Actions {
	
	[ActionCategory("Mobile Social Plugin - Facebook")]
	public class MSP_FB_NativePostWithTexture : FsmStateAction {
		
		public FsmString message;
		public FsmTexture texture;
		
		
		public override void OnEnter() {
			
			SPShareUtility.FacebookShare(message.Value, texture.Value  as Texture2D);
			Finish();
			
		}
	}
}



