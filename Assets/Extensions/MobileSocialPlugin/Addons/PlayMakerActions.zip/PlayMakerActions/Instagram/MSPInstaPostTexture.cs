using UnityEngine;
using System.Collections;


namespace HutongGames.PlayMaker.Actions {
	
	[ActionCategory("Mobile Social Plugin - Other")]
	public class MSPInstaPostTexture : FsmStateAction {
		
		public FsmString message;
		public FsmTexture texture;
		
		public FsmEvent successEvent;
		public FsmEvent failEvent;
		
		
		public override void OnEnter() {
			
			bool IsInEdditorMode = false;
			
			#if UNITY_EDITOR
			IsInEdditorMode = true;
			#endif
			
			
			if(IsInEdditorMode) {
				Fsm.Event(successEvent);
				Finish();
				return;
			}
			
			SPInstagram.addEventListener(InstagramEvents.POST_SUCCEEDED, 	OnPostSuccses);
			SPInstagram.addEventListener(InstagramEvents.POST_FAILED, 		OnPostFailed);

			
			SPInstagram.Share(texture.Value as Texture2D, message.Value);
			
		}

		private void RemoveListners() {
			SPInstagram.removeEventListener(InstagramEvents.POST_SUCCEEDED, 	OnPostSuccses);
			SPInstagram.removeEventListener(InstagramEvents.POST_FAILED, 		OnPostFailed);
		}
		
		
		private void OnPostFailed() {
			Fsm.Event(failEvent);
			RemoveListners();
			Finish();
		}
		
		private void OnPostSuccses() {
			Fsm.Event(successEvent);
			RemoveListners();
			Finish();
		}
		
	}
}



