using UnityEngine;
using System.Collections;


namespace HutongGames.PlayMaker.Actions {
	
	[ActionCategory("Mobile Social Plugin - Twitter")]
	public class MSP_TwitterPost : FsmStateAction {

		public FsmString message;


		public FsmEvent successEvent;
		public FsmEvent failEvent;
		

		public override void OnEnter() {

			bool IsInEdditorMode = false;
			
			#if UNITY_EDITOR
			IsInEdditorMode = true;
			#endif
			
			
			if(IsInEdditorMode) {
				Fsm.Event(successEvent);
				Finish();
				return;
			}


			SPTwitter.instance.addEventListener(TwitterEvents.POST_SUCCEEDED,  OnPostSuccess);
			SPTwitter.instance.addEventListener(TwitterEvents.POST_FAILED,  	  OnPostFailed);


			SPTwitter.instance.Post(message.Value);

		}

		private void RemoveListners() {
			SPTwitter.instance.removeEventListener(TwitterEvents.POST_SUCCEEDED,  OnPostSuccess);
			SPTwitter.instance.removeEventListener(TwitterEvents.POST_FAILED,  	  OnPostFailed);
		}

		private void OnPostFailed() {
			Fsm.Event(failEvent);
			RemoveListners();
			Finish();
		}
		
		private void OnPostSuccess() {
			Fsm.Event(successEvent);
			RemoveListners();
			Finish();
		}

	}
}


