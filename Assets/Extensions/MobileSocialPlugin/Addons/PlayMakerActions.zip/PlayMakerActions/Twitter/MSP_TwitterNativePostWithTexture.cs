using UnityEngine;
using System.Collections;


namespace HutongGames.PlayMaker.Actions {
	
	[ActionCategory("Mobile Social Plugin - Twitter")]
	public class MSP_TwitterNativePostWithTexture : FsmStateAction {

		public FsmString message;
		public FsmTexture texture;
		
		
		
		public override void OnEnter() {
			
			SPShareUtility.TwitterShare(message.Value, texture.Value  as Texture2D);
			Finish();
			
		}
	}
}


