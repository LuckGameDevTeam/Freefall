﻿using UnityEngine;
using UnionAssets.FLE;
using System.Collections;

namespace HutongGames.PlayMaker.Actions {
		
	[ActionCategory("Mobile Social Plugin - Twitter")]
	public class MSP_TwitterUserLookUpRequest : FsmStateAction {
			
		public FsmEvent successEvent;
		public FsmEvent failEvent;

		public FsmString user_id;

		public FsmString id;
		public FsmString name;
		public FsmString screen_name;
		public FsmInt friends_count;
		public FsmString profile_image_url;
		public FsmString profile_image_url_https;
		
		public override void OnEnter() {	
			TW_UsersLookUpRequest r =  TW_UsersLookUpRequest.Create();
			r.addEventListener(BaseEvent.COMPLETE, OnLookUpRequestComplete);
			if (user_id.Value.Length > 0) {
				r.AddParam("user_id", user_id.Value);
			}
			r.Send();
		}
		
		private void OnLookUpRequestComplete(CEvent e) {
			TW_APIRequstResult result = e.data as TW_APIRequstResult;
						
			if(result.IsSucceeded) {
				this.id.Value = result.users[0].id;
				this.name.Value = result.users[0].name;
				this.screen_name.Value = result.users[0].screen_name;
				this.friends_count.Value = result.users[0].friends_count;
				this.profile_image_url.Value = result.users[0].profile_image_url;
				this.profile_image_url_https.Value = result.users[0].profile_image_url_https;

				Fsm.Event(successEvent);
				Finish();
			} else {
				Fsm.Event(failEvent);
				Finish();
			}
		}
	}
}
